"""
Audit logging for lambdas: `Logger`.

A thin layer over a result stream that tags each entry with a severity and drops entries
below the configured level. Vended by `JobContext.logger(name)`; the runtime builds it
on the lambda's chosen log stream with the batch's `log_level` and wires it to the shared
streaming machinery (so it inherits the streamer's thread-safety).
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2023-2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

from collections.abc import Callable, Iterable
from typing import Any, Final

from .streaming import ResultStreamer, StreamFlusher
from .types import AtmObject


# Severity -> numeric level. Higher number == more verbose; a logger keeps entries
# whose level is at or below its threshold (i.e. of equal-or-higher importance).
LOG_LEVELS: Final[dict[str, int]] = {
    "debug": 7,
    "info": 6,
    "notice": 5,
    "warning": 4,
    "error": 3,
    "critical": 2,
    "alert": 1,
    "emergency": 0,
}

DEFAULT_LOG_LEVEL: Final[str] = "info"


def normalize_severity(severity: str) -> str:
    return severity if severity in LOG_LEVELS else DEFAULT_LOG_LEVEL


class Logger(ResultStreamer[AtmObject]):
    """A severity-filtered result streamer for `{severity, content}` log entries."""

    def __init__(
        self,
        *,
        result_name: str,
        buffered: bool,
        flusher: StreamFlusher,
        heartbeat: Callable[[], None],
        out_dir: str | None = None,
        log_level: str = DEFAULT_LOG_LEVEL,
    ) -> None:
        super().__init__(
            result_name=result_name,
            buffered=buffered,
            flusher=flusher,
            heartbeat=heartbeat,
            out_dir=out_dir,
        )
        self._threshold = LOG_LEVELS[normalize_severity(log_level)]

    def stream_items(self, items: Iterable[AtmObject]) -> None:
        kept = [item for item in items if LOG_LEVELS[self._severity_of(item)] <= self._threshold]
        super().stream_items(kept)

    @staticmethod
    def _severity_of(item: AtmObject) -> str:
        try:
            return normalize_severity(item["severity"])
        except (KeyError, TypeError):
            return DEFAULT_LOG_LEVEL

    def log(self, severity: str, content: Any) -> None:
        self.stream_item({"severity": severity, "content": content})

    def debug(self, content: Any) -> None:
        self.log("debug", content)

    def info(self, content: Any) -> None:
        self.log("info", content)

    def notice(self, content: Any) -> None:
        self.log("notice", content)

    def warning(self, content: Any) -> None:
        self.log("warning", content)

    def error(self, content: Any) -> None:
        self.log("error", content)

    def critical(self, content: Any) -> None:
        self.log("critical", content)

    def alert(self, content: Any) -> None:
        self.log("alert", content)

    def emergency(self, content: Any) -> None:
        self.log("emergency", content)
