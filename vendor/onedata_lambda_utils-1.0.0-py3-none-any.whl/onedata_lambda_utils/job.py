"""
The handler API: the per-job unit (`Job`), the shared batch context (`JobContext`), and
the failure signal (`JobException`) -- what a handler signs against.

These are SDK-local authoring abstractions, not the wire contract, so they carry no `Atm`
prefix (unlike `AtmFile`, `AtmException`, … which mirror what crosses the wire).
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

from .types import LogLevel


if TYPE_CHECKING:
    from ._wire import AtmJobBatchRequestCtx
    from .logging import Logger
    from .streaming import ResultStreamer


class JobException(Exception):
    """
    Raised by a handler to fail a job with a known, message-only error.

    The SDK turns it into an `AtmException` entry carrying just `str(exception)` -- no
    traceback -- so an expected failure (bad config, a failed REST call)
    reads cleanly in the results. Any *other* exception is treated as an unexpected bug
    and reported with a full traceback instead.
    """


@dataclass(frozen=True)
class Job[A]:
    """
    A single unit of work passed to a handler.

    `args` is the job's input (the lambda's typed arguments). `trace_id` identifies this
    job across logs and streamed results; it comes from the wire (the framework assigns
    it) and lives on the job -- not on the shared context, which is common to all jobs of
    a batch, including in parallel.
    """

    args: A
    trace_id: str


class JobContext[C]:
    """
    The shared, per-batch context handed to a handler alongside its jobs.

    Carries the (typed) task `config`, read-only identity/infrastructure fields, and the
    runtime services. Services (`logger(name)`, `heartbeat()`, `result_streamer(name)`)
    are vended by the context rather than imported globally, so they can hook into the
    runtime (heartbeat-on-flush, the shared streaming flusher, dev-mode). They are
    thread-safe; per-job state must never be stored here -- it travels on `Job`.

    There is no default log stream: a lambda picks its stream names itself (and declares
    them in its workflow schema), so `logger(name)` requires the name explicitly -- just
    like `result_streamer(name)`. "logs" is only a common convention, not a requirement.

    `raw` is an escape hatch to the full wire request context for fields not surfaced
    here. The runtime (`run()`) constructs this; handlers only read it.
    """

    def __init__(
        self,
        *,
        config: C,
        user_id: str,
        space_id: str,
        workflow_execution_id: str,
        oneprovider_id: str,
        oneprovider_domain: str,
        onezone_domain: str,
        access_token: str,
        timeout_seconds: int,
        log_level: LogLevel,
        heartbeat: Callable[[], None],
        result_streamer_factory: "Callable[..., ResultStreamer]",
        logger_factory: "Callable[[str], Logger]",
        raw: "AtmJobBatchRequestCtx[C]",
    ) -> None:
        self.config = config
        self.user_id = user_id
        self.space_id = space_id
        self.workflow_execution_id = workflow_execution_id
        self.oneprovider_id = oneprovider_id
        self.oneprovider_domain = oneprovider_domain
        self.onezone_domain = onezone_domain
        self.access_token = access_token
        self.timeout_seconds = timeout_seconds
        self.log_level = log_level
        self.raw = raw
        self._heartbeat = heartbeat
        self._result_streamer_factory = result_streamer_factory
        self._logger_factory = logger_factory

    def heartbeat(self) -> None:
        """Signal progress for the current job (throttled by the runtime)."""
        self._heartbeat()

    def result_streamer(self, name: str, *, buffered: bool = True) -> "ResultStreamer":
        """Open a result/measurement stream by name (buffered by default)."""
        return self._result_streamer_factory(name, buffered=buffered)

    def logger(self, name: str) -> "Logger":
        """
        Open an audit-log stream by name, filtered to the batch's log level.

        The name is the lambda's choice (declare it in the workflow schema); "logs" is a
        common convention, not a requirement. Logs are written unbuffered, so they are
        kept even if the handler crashes mid-batch.
        """
        return self._logger_factory(name)
