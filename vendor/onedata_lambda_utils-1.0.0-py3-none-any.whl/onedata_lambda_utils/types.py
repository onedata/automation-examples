"""
Public data types for Onedata Automation lambdas: the JSON shapes of Onedata entities a
handler receives or produces (`AtmFile`, `AtmDataset`, `AtmObject`, …), mirroring the
public Onedata API, plus `AtmException` (the per-job failure marker).
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2022-2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

from typing import Any, Literal, NotRequired, TypedDict


##===================================================================
## Basic automation data types
##===================================================================


type FileType = Literal["REG", "DIR", "SYMLNK"]
type ProtectionFlag = Literal["data_protection", "metadata_protection"]
type InheritancePath = Literal["none", "direct", "ancestor", "direct_and_ancestor"]
type LogLevel = Literal[
    "debug",
    "info",
    "notice",
    "warning",
    "error",
    "critical",
    "alert",
    "emergency",
]

type AtmObject = dict[str, Any]
"""Generic JSON object."""


class AtmDataset(TypedDict):
    """
    JSON object describing dataset.

    Refer to the API specification for more information:
    https://onedata.org/#/home/api/latest/oneprovider?anchor=operation/get_dataset
    """

    state: Literal["attached", "detached"]
    datasetId: str
    parentId: str | None
    rootFileId: str
    rootFileType: FileType
    rootFilePath: str
    rootFileDeleted: bool
    protectionFlags: list[ProtectionFlag]
    effectiveProtectionFlags: list[ProtectionFlag]
    creationTime: int
    archiveCount: int


class AtmFile(TypedDict, total=False):
    """
    JSON object describing a file in Onedata filesystem.

    Refer to the API specification for more information:
    https://onedata.org/#/home/api/latest/oneprovider?anchor=operation/get_attrs

    NOTE: dynamic fields like `xattr.*` are not typed due to limitations
    of typing machinery.
    """

    fileId: str
    index: str
    type: FileType
    activePermissionsType: Literal["posix", "acl"]
    posixPermissions: str
    acl: list[dict]
    name: str
    conflictingName: str | None
    path: str
    parentFileId: str | None
    displayGid: int
    displayUid: int
    atime: int
    mtime: int
    ctime: int
    size: int | None
    isFullyReplicatedLocally: bool | None
    localReplicationRate: float
    originProviderId: str
    directShareIds: list[str]
    ownerUserId: str
    hardlinkCount: int
    symlinkValue: str | None
    hasCustomMetadata: bool
    effProtectionFlags: list[ProtectionFlag]
    effDatasetProtectionFlags: list[ProtectionFlag]
    effDatasetInheritancePath: InheritancePath
    effQosInheritancePath: InheritancePath
    aggregateQosStatus: Literal["fulfilled", "pending", "impossible"]
    archiveRecallRootFileId: str | None


class AtmGroup(TypedDict):
    """
    JSON object describing group.

    Refer to the API specification for more information:
    https://onedata.org/#/home/api/latest/onezone?anchor=operation/get_group
    """

    groupId: str
    name: str
    type: Literal["organization", "unit", "team", "role_holders"]


class AtmRange(TypedDict):
    """
    JSON object describing a sequence of integers.

    AtmRange is a sequence of integers produced from the start to end by step.

    Fields
    --------
    end
        Value for which the sequence of integers will exclusively end.
        If step value is positive, end value must be higher than start value.
        Otherwise end value must be lower than start value.
    start
        Starting value for which the sequence of integers will inclusively start.
        If step value is positive, start value must be lower than end value.
        Otherwise start value must be higher than end value.
        By default, it's set to: 0.
    step
        Value which specifies the size of incrementation or decrementation.
        It cannot be equal 0, and by default, it's set to: 1.

    Examples
    --------
    AtmRange(start=10, end=20, step=2) -> [10, 12, 14, 16, 18]
    AtmRange(start=10, end=-10, step=-4) -> [10, 6, 2, -2, -6]
    AtmRange(end=10, step=6) -> [0, 6]
    AtmRange(end=5) -> [0, 1, 2, 3, 4]
    AtmRange(start=4, end=-1, step=-1) -> [4, 3, 2, 1, 0]
    AtmRange(start=5, end=5, step=-2) -> []
    AtmRange(start=4, end=5, step=-2) -> Invalid!
    """

    end: int
    start: NotRequired[int]
    step: NotRequired[int]


class AtmTimeSeriesMeasurement(TypedDict):
    """
    JSON object describing time series measurement.

    Time series measurement is a named value-timestamp pair which expresses some
    property that can be dynamically changing (like file size, network speed, etc.).
    Such measurements can be aggregated within time series stores and
    serve as a data source for GUI charts.
    """

    tsName: str
    timestamp: int
    value: float


class AtmException(TypedDict):
    """
    The exception envelope -- a failure reported on the wire as `{"exception": ...}`.

    One shape, used at two levels:

    * **per-job** -- returned in a handler's results list (in place of a result) to fail a
      single job without failing the whole batch; `run()` passes it through.
    * **whole-batch** -- returned by `run()` as the entire response (replacing
      `resultsBatch`) when the batch fails before producing per-job results -- a malformed
      request, a failed Oneclient mount, or a batch-level handler exception.
    """

    exception: float | str | AtmObject
