"""
SDK for writing Onedata Automation lambdas.

Public surface: the handler API (`Job`, `JobContext`, `JobException`), the contract
runtime (`run`, `per_job`), the Onedata wire/contract field types (the `Atm*` names),
the time-series measurement builder, and the mounted-Oneclient helpers.

Naming convention: `Atm*` marks the Onedata Automation *contract* -- the JSON shapes that
cross the wire to/from the provider (`AtmFile`, `AtmException`, …). Everything the SDK adds
purely as authoring ergonomics (`Job`, `JobContext`, `JobException`, `ResultStreamer`,
`TimeSeriesMeasurementBuilder`, …) is SDK-local and carries no prefix.
"""

from .job import Job, JobContext, JobException
from .oneclient import mount_point, mounted_file_path
from .perjob import DEFAULT_MAX_WORKERS, per_job
from .runtime import run
from .stats import TimeSeriesMeasurementBuilder
from .types import (
    AtmDataset,
    AtmException,
    AtmFile,
    AtmGroup,
    AtmObject,
    AtmRange,
    AtmTimeSeriesMeasurement,
    FileType,
    InheritancePath,
    LogLevel,
    ProtectionFlag,
)


__all__ = [
    # runtime
    "run",
    "per_job",
    "DEFAULT_MAX_WORKERS",
    # handler API
    "Job",
    "JobContext",
    "JobException",
    # mounted Oneclient helpers
    "mount_point",
    "mounted_file_path",
    # wire/contract field types (Atm*)
    "AtmException",
    "AtmObject",
    "AtmDataset",
    "AtmFile",
    "AtmGroup",
    "AtmRange",
    "AtmTimeSeriesMeasurement",
    "FileType",
    "ProtectionFlag",
    "InheritancePath",
    "LogLevel",
    # builders
    "TimeSeriesMeasurementBuilder",
]
