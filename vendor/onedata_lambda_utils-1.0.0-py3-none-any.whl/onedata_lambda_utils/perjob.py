"""
The per-job handler adapter: `@per_job`.

Lets a handler be written in the natural per-job style -- `handle(job, ctx) -> result`
-- and adapts it into the batch-level handler `run()` calls, so the runtime stays
agnostic about the style used. Sibling of `runtime.run` (the batch entry point).
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2022-2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

import functools
import traceback
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .job import Job, JobContext, JobException
from .types import AtmException


# A per-job handler: one job in, one result out.
PerJobHandler = Callable[[Job[Any], JobContext[Any]], Any]
# A batch-level handler (what the runtime calls).
BatchHandler = Callable[[list[Job[Any]], JobContext[Any]], list[Any]]
# A once-per-batch precondition: validate config / set up shared state before any job runs.
Precondition = Callable[[JobContext[Any]], None]

# Default worker count for parallel `@per_job`. A deliberate fixed value, *not* derived
# from `os.cpu_count()`: that returns the host's cores and ignores the pod's cgroup CPU
# limit (and there is no `os.process_cpu_count()` on 3.12), and peak memory grows with the
# worker count (each job may hold a read buffer). Lambdas whose profile differs pass their
# own `max_workers`.
DEFAULT_MAX_WORKERS = 10


def per_job(
    handle: PerJobHandler | None = None,
    *,
    max_workers: int = 1,
    precondition: Precondition | None = None,
) -> Any:
    """
    Adapt a per-job `handle(job, ctx) -> result` into the batch handler `run()` calls.

    The SDK owns the batch loop: it runs each job, turns a per-job exception into an
    `AtmException` entry (so one bad job fails only itself), assembles results in input
    order, and heartbeats as each job completes. Sequential by default; `max_workers > 1`
    runs jobs on a thread pool (the context services are thread-safe) -- pass
    `DEFAULT_MAX_WORKERS` for the SDK's standard degree of parallelism. Usable bare
    (`@per_job`) or parameterized (`@per_job(max_workers=4)`).

    `precondition`, if given, runs **once** before any job is dispatched -- the place for
    task-level validation (e.g. a config check) or one-time setup. Raising `JobException`
    there fails the whole batch with a single clean top-level `{"exception": ...}` (via
    `run()`), rather than repeating a per-job failure across every job.
    """

    def decorate(handle_one: PerJobHandler) -> BatchHandler:
        # Copy name/qualname/doc/module so tracebacks and introspection point at the
        # user's handler -- but NOT __annotations__: run_batch has the batch signature
        # (jobs, ctx), which differs from handle_one's per-job (job, ctx).
        @functools.wraps(
            handle_one,
            assigned=("__module__", "__name__", "__qualname__", "__doc__"),
        )
        def run_batch(jobs: list[Job[Any]], ctx: JobContext[Any]) -> list[Any]:
            if precondition is not None:
                # Runs once for the batch; a JobException here propagates to run()'s
                # top-level handler -> clean whole-batch {"exception": ...}.
                precondition(ctx)
            if max_workers <= 1:
                return _run_sequential(handle_one, jobs, ctx)
            return _run_parallel(handle_one, jobs, ctx, max_workers)

        return run_batch

    # Support both bare `@per_job` and parameterized `@per_job(max_workers=N)`.
    if handle is not None:
        return decorate(handle)

    return decorate


def _run_sequential(
    handle_one: PerJobHandler, jobs: list[Job[Any]], ctx: JobContext[Any]
) -> list[Any]:
    results = []
    for job in jobs:
        results.append(_run_one(handle_one, job, ctx))
        ctx.heartbeat()
    return results


def _run_parallel(
    handle_one: PerJobHandler,
    jobs: list[Job[Any]],
    ctx: JobContext[Any],
    max_workers: int,
) -> list[Any]:
    results: list[Any] = [None] * len(jobs)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_index = {
            executor.submit(_run_one, handle_one, job, ctx): index for index, job in enumerate(jobs)
        }
        for future in as_completed(future_to_index):
            index = future_to_index[future]
            results[index] = future.result()  # _run_one never raises
            ctx.heartbeat()
    return results


def _run_one(handle_one: PerJobHandler, job: Job[Any], ctx: JobContext[Any]) -> Any:
    try:
        return handle_one(job, ctx)
    except JobException as ex:
        # A known, expected failure -- report just the message, no traceback noise.
        return AtmException(exception=str(ex))
    except Exception:
        # An unexpected bug -- keep the full traceback for debugging.
        return AtmException(exception=traceback.format_exc())
