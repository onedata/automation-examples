"""
Streaming lambda results and measurements to `/out/<name>`.

Beyond the per-job results a handler returns, a lambda can append items incrementally to
named streams (audit logs, time-series measurements, large result sets); this module
owns that path. The runtime owns the flusher's lifecycle -- lazily started on first
buffered use and drained-and-stopped when the handler returns (see `runtime.run`).
Everything here is thread-safe.
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2022-2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

import json
import os
import threading
from collections.abc import Callable, Iterable
from typing import Any, Final


OUT_DIR: Final[str] = "/out"

# How often the background flusher drains buffered items.
FLUSH_INTERVAL_SEC: Final[float] = 1.0


class StreamFlusher:
    """
    A single background thread batching writes for all buffered streams of one run.

    Producers `enqueue` `(stream_name, item)` pairs (cheap, lock-guarded). The
    thread wakes periodically, writes everything buffered grouped by stream, and -- only
    if it actually wrote something -- emits a heartbeat (itself throttled by the
    runtime). The thread starts lazily on first `enqueue` so idle lambdas pay nothing.
    """

    def __init__(
        self,
        *,
        heartbeat: Callable[[], None],
        out_dir: str | None = None,
        interval: float = FLUSH_INTERVAL_SEC,
    ) -> None:
        self._heartbeat = heartbeat
        self._out_dir = out_dir if out_dir is not None else OUT_DIR
        self._interval = interval
        self._buffer: list[tuple[str, Any]] = []
        self._buffer_lock = threading.Lock()
        self._start_lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def enqueue(self, name: str, item: Any) -> None:
        self.enqueue_many(name, [item])

    def enqueue_many(self, name: str, items: list[Any]) -> None:
        if not items:
            return

        self._ensure_started()
        with self._buffer_lock:
            self._buffer.extend((name, item) for item in items)

    def _ensure_started(self) -> None:
        if self._thread is not None:
            return

        with self._start_lock:
            if self._thread is None:
                thread = threading.Thread(target=self._loop, daemon=True)
                self._thread = thread
                thread.start()

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._stop.wait(self._interval)
            self._flush_once()

    def _flush_once(self) -> None:
        with self._buffer_lock:
            if not self._buffer:
                return

            pending = self._buffer
            self._buffer = []

        by_name: dict[str, list[Any]] = {}
        for name, item in pending:
            by_name.setdefault(name, []).append(item)
        for name, items in by_name.items():
            _append_to_stream(self._out_dir, name, items)

        # Activity-gated: heartbeat only because we made observable progress.
        self._heartbeat()

    def stop(self) -> None:
        """Stop the thread and drain remaining buffered items (no-op if unused)."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
        self._flush_once()


class ResultStreamer[T]:
    """
    Streams items to `/out/<result_name>`. Two modes, neither needing a manual flush:

    * **buffered (default)** -- enqueues into the shared background flusher, which batches
      writes across all buffered streams and heartbeats after each non-empty flush. Best
      for high-frequency / multi-threaded producers.
    * **direct** (`buffered=False`) -- writes immediately and heartbeats (throttled) per
      write. Best for low-frequency output or callers doing their own batching.

    Vended by `JobContext.result_streamer(name, *, buffered=...)`; the runtime injects
    the shared flusher and the heartbeat. Construct directly only in tests.
    """

    def __init__(
        self,
        *,
        result_name: str,
        buffered: bool,
        flusher: StreamFlusher,
        heartbeat: Callable[[], None],
        out_dir: str | None = None,
    ) -> None:
        self.result_name = result_name
        self._buffered = buffered
        self._flusher = flusher
        self._heartbeat = heartbeat
        self._out_dir = out_dir if out_dir is not None else OUT_DIR
        self._write_lock = threading.Lock()

    def stream_item(self, item: T) -> None:
        self.stream_items([item])

    def stream_items(self, items: Iterable[T]) -> None:
        materialized = list(items)
        if not materialized:
            return

        if self._buffered:
            # One lock acquisition for the whole batch, not one per item.
            self._flusher.enqueue_many(self.result_name, materialized)
        else:
            with self._write_lock:
                _append_to_stream(self._out_dir, self.result_name, materialized)

            # Direct mode: heartbeat per write (throttled by the runtime).
            self._heartbeat()


def _append_to_stream(out_dir: str, name: str, items: list[Any]) -> None:
    with open(os.path.join(out_dir, name), "a") as stream_file:
        for item in items:
            json.dump(item, stream_file)
            stream_file.write("\n")
