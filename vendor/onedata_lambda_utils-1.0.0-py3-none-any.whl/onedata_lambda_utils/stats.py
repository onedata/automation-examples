"""Time-series measurements for lambdas."""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2022-2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"


import time

from .types import AtmTimeSeriesMeasurement


class TimeSeriesMeasurementBuilder:
    """Base class for time series measurement builders.

    In order to create a builder for concrete time series measurement, create
    a class deriving from TimeSeriesMeasurementBuilder with following
    metadata specified:
    - ts_name - used as exact name of the measurement
    - unit - stored only as metadata and not processed in any way

    Example usage:
    >>>
    >>> import pprint
    >>>
    >>> from onedata_lambda_utils import TimeSeriesMeasurementBuilder
    >>>
    >>>
    >>> class FilesProcessed(
    >>>     TimeSeriesMeasurementBuilder, ts_name="filesProcessed", unit=None
    >>> ):
    >>>     pass
    >>>
    >>>
    >>> pprint.pprint(FilesProcessed.build(value=34, timestamp=100))

         {'timestamp': 100, 'tsName': 'filesProcessed', 'value': 34}
    """

    _ts_name: str
    _unit: str | None

    def __init_subclass__(cls, ts_name: str, unit: str | None) -> None:
        cls._ts_name = ts_name
        cls._unit = unit

    @classmethod
    def build(cls, value: float, *, timestamp: int | None = None) -> AtmTimeSeriesMeasurement:
        return {
            "tsName": cls._ts_name,
            "timestamp": int(time.time()) if timestamp is None else timestamp,
            "value": value,
        }
