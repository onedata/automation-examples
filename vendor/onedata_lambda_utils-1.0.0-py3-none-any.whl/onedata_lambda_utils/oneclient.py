"""
Helpers for lambdas that read files through a mounted Oneclient.

The mount point is a deployment fact: the platform mounts Oneclient at
`ONECLIENT_MOUNT_POINT` -- the same variable the runtime waits on before handing a batch
to a mounted lambda (see `runtime._await_oneclient_mount`). Reading it here, in one place,
together with Oneclient's id-based path convention, keeps every mounted lambda agreeing
with the runtime instead of hardcoding a path that can silently drift.
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

import os
from typing import Final


# Environment variable carrying the Oneclient mount point (set by the platform).
ENV_MOUNT_POINT: Final[str] = "ONECLIENT_MOUNT_POINT"

# Fallback used only for local dev / tests; in production the platform always sets the env.
DEFAULT_MOUNT_POINT: Final[str] = "/mnt/onedata"


def mount_point() -> str:
    """
    The Oneclient mount point, read from the environment at call time.

    Falls back to `DEFAULT_MOUNT_POINT` for local dev/tests; in production the platform
    always sets `ONECLIENT_MOUNT_POINT`. Read at call time (not import time) so tests can
    point the mount elsewhere via the environment.
    """
    return os.environ.get(ENV_MOUNT_POINT) or DEFAULT_MOUNT_POINT


def mounted_file_path(file_id: str) -> str:
    """
    Absolute path of a file, by its id, under the Oneclient mount.

    Oneclient exposes every file at a stable id-based path
    (`<mount>/.__onedata__file_id__<id>`), so a lambda can open a file knowing only its id,
    without resolving its logical location.
    """
    return f"{mount_point()}/.__onedata__file_id__{file_id}"
