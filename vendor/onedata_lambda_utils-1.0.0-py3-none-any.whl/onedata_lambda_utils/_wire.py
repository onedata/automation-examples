"""
Internal wire types: the raw JSON shapes exchanged between Oneprovider and a lambda.

These model the OpenFaaS job-batch request/response protocol verbatim (camelCase, as
sent on the wire). They are an implementation detail parsed by `run()` and are NOT
part of the public handler API -- handlers work with `Job` / `JobContext`
instead (see `job`). The full request context remains reachable as an escape hatch
via `JobContext.raw`.
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

from collections.abc import Sequence
from typing import TypedDict

from .types import AtmException, LogLevel


class AtmJobBatchRequestCtx[C](TypedDict):
    """
    JSON object describing job batch request context.

    Fields
    --------
    userId
        Id of the scheduling user.
    spaceId
        Id of the space in context of which the workflow is executed.
    atmWorkflowExecutionId
        Workflow execution Id.
    oneproviderDomain
        Domain of job scheduling Oneprovider.
    oneproviderId
        Id of job scheduling Oneprovider.
    onezoneDomain
        The domain of the Onezone service that manages the Onedata environment.
    accessToken
        Token used to authorize operations in Onedata.

        Refer to the API specification for more information:
        https://onedata.org/#/home/documentation/latest/doc/using_onedata/tokens[access-tokens].html
    heartbeatUrl
        The target url for sending heartbeats.
    timeoutSeconds
        The time interval from last heartbeat after which job batch is marked as failed.
    logLevel
        Level controlling the amount of information recorded in audit logs as only logs
        with severity equal or higher to this level will be stored.
    config
        User defined task configuration.
    """

    userId: str
    spaceId: str
    atmWorkflowExecutionId: str
    oneproviderDomain: str
    oneproviderId: str
    onezoneDomain: str
    accessToken: str
    heartbeatUrl: str
    timeoutSeconds: int
    logLevel: LogLevel
    config: C


class AtmJobMeta(TypedDict):
    """Per-job metadata the framework attaches to each job's args object on the wire."""

    traceId: str


# Functional syntax because `__meta` is a dunder key (a class-body annotation would be
# name-mangled). Each wire args object also carries the lambda's own argument keys
# alongside `__meta`; the runtime strips `__meta` off (-> Job.trace_id) and hands the
# rest to the handler as the job's args.
AtmJobArgs = TypedDict("AtmJobArgs", {"__meta": AtmJobMeta})


class AtmJobBatchRequest[C](TypedDict):
    """
    JSON object describing job batch request.

    Fields
    --------
    ctx
        Context of job batch request.
    argsBatch
        List of per-job args objects. Each carries a `__meta` envelope (the job's
        `traceId`) alongside the lambda's own input arguments.
    """

    ctx: AtmJobBatchRequestCtx[C]
    argsBatch: list[AtmJobArgs]


class AtmJobBatchResponse[R](TypedDict):
    """
    JSON object describing job batch response.

    Fields
    --------
    resultsBatch
        List of JSON objects, each carrying results of a single job (lambda output).
        The length of this list must be equal to the length of the corresponding
        AtmJobBatchRequest.argsBatch. However, if the lambda returns empty results for
        each job, the resultsBatch can be set to None.
    """

    resultsBatch: Sequence[AtmException | R | None] | None
