"""
Helpers for unit-testing lambda handlers without Docker, network, or the runtime.

Build a synthetic context and jobs, call your handler directly, then assert on both its
return value and its side effects -- heartbeats, logs and streamed items, captured in
memory per name:

    from onedata_lambda_sdk.testing import build_job_context, build_jobs

    rc = build_job_context(config={"threshold": 5})
    results = handle(build_jobs([{"x": 1}, {"x": 2}]), rc.context)

    assert results == [...]
    assert rc.heartbeats == 2
    assert rc.streams["stats"] == [...]
    assert rc.logs["logs"] == [{"severity": "info", "content": "..."}]

Works for batch handlers and for `@per_job` handlers alike -- a decorated
per-job handler already has the batch signature. To test the per-job function in
isolation, call it with a single `build_jobs([...])[0]` and `rc.context`.

For an end-to-end check through the *real* runtime, use `run_local`:

    from onedata_lambda_sdk.testing import build_request, run_local

    result = run_local(handle, build_request([{"x": 1}], config={"k": "v"}), out_dir=tmp_path)
    assert result.envelope == {"resultsBatch": [...]}
    assert result.streams["stats"] == [...]

It drives `run(handler, raw)` in dev mode and returns the response envelope plus the items
each `/out/<stream>` received -- exercising the seam the unit helpers skip (wire parsing,
`JobContext` construction, the buffered flusher writing files, envelope assembly).
"""

__author__ = "Bartosz Walkowicz"
__copyright__ = "Copyright (C) 2026 Onedata (onedata.org)"
__license__ = "This software is released under the MIT license cited in LICENSE.txt"

import contextlib
import json
import os
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import Any

from ._wire import AtmJobBatchRequestCtx
from .job import Job, JobContext
from .logging import Logger
from .runtime import ENV_DEV_MODE, run
from .streaming import ResultStreamer
from .types import AtmObject, LogLevel


# --- Unit testing: the handler in isolation ------------------------------------------
# Drive a handler directly against a synthetic JobContext whose services (heartbeat,
# streamers, loggers) record into memory instead of touching the network or `/out`.


class _Counter:
    """A mutable integer cell shared between the heartbeat closure and `RecordedContext`."""

    def __init__(self) -> None:
        self.value = 0

    def increment(self) -> None:
        self.value += 1


class _RecordingStreamer(ResultStreamer[Any]):
    """A streamer that captures items in a list instead of writing to `/out`."""

    # Deliberately bypasses ResultStreamer.__init__ (no flusher/heartbeat/out_dir needed):
    # both public methods are overridden to append to the sink, so no inherited code runs.
    def __init__(self, result_name: str, sink: list[Any]) -> None:
        self.result_name = result_name
        self._sink = sink

    def stream_item(self, item: Any) -> None:
        self._sink.append(item)

    def stream_items(self, items: Iterable[Any]) -> None:
        self._sink.extend(items)


class _RecordingLogger(Logger):
    """A logger that captures all entries (no level filtering) instead of writing out."""

    # Like _RecordingStreamer, bypasses the parent __init__; stream_items is overridden to
    # capture every entry, so the level threshold the real Logger applies is intentionally
    # skipped -- a test sees all emitted logs regardless of `log_level`.
    def __init__(self, result_name: str, sink: list[AtmObject]) -> None:
        self.result_name = result_name
        self._sink = sink

    def stream_items(self, items: Iterable[AtmObject]) -> None:
        self._sink.extend(items)


class RecordedContext:
    """A synthetic `JobContext` plus the side effects captured during a test."""

    def __init__(
        self,
        context: JobContext[Any],
        logs: dict[str, list[AtmObject]],
        streams: dict[str, list[Any]],
        heartbeats: _Counter,
    ) -> None:
        self.context = context
        # Log entries the handler emitted, keyed by log stream name (captured regardless of
        # level -- the recording logger does not filter; see _RecordingLogger).
        self.logs = logs
        # Streamed items keyed by stream name.
        self.streams = streams
        self._heartbeats = heartbeats

    @property
    def heartbeats(self) -> int:
        """
        How many times the handler called `ctx.heartbeat()` explicitly.

        Unlike the real runtime, the recording streamers/loggers do not emit heartbeats,
        so this counts only direct `ctx.heartbeat()` calls.
        """
        return self._heartbeats.value


def build_jobs(args_batch: list[Any]) -> list[Job[Any]]:
    """Wrap a list of argument objects into `Job`s with synthetic trace ids."""
    return [Job(args=args, trace_id=f"test-{i}") for i, args in enumerate(args_batch)]


def build_job_context(
    *,
    config: Any = None,
    log_level: LogLevel = "info",
    user_id: str = "test-user",
    space_id: str = "test-space",
    workflow_execution_id: str = "test-workflow-execution",
    oneprovider_id: str = "test-oneprovider",
    oneprovider_domain: str = "oneprovider.test",
    onezone_domain: str = "onezone.test",
    access_token: str = "test-token",
    timeout_seconds: int = 120,
) -> RecordedContext:
    """
    Build a synthetic `JobContext` whose services record into memory.

    Returns a `RecordedContext` exposing the context (`.context`) plus the captured
    `.logs`, `.streams` and `.heartbeats`.

    Note: captured logs are *not* level-filtered -- `log_level` is stored on the context,
    but the recording logger keeps every entry, so a test sees all emitted logs. To
    exercise real level filtering, go through `run_local`.
    """
    logs: dict[str, list[AtmObject]] = {}
    streams: dict[str, list[Any]] = {}
    heartbeats = _Counter()

    def heartbeat() -> None:
        heartbeats.increment()

    streamers: dict[str, _RecordingStreamer] = {}

    def result_streamer_factory(name: str, *, buffered: bool = True) -> ResultStreamer[Any]:
        streamer = streamers.get(name)
        if streamer is None:
            streamer = _RecordingStreamer(name, streams.setdefault(name, []))
            streamers[name] = streamer
        return streamer

    loggers: dict[str, _RecordingLogger] = {}

    def logger_factory(name: str) -> Logger:
        logger = loggers.get(name)
        if logger is None:
            logger = _RecordingLogger(name, logs.setdefault(name, []))
            loggers[name] = logger
        return logger

    raw: AtmJobBatchRequestCtx[Any] = AtmJobBatchRequestCtx(
        userId=user_id,
        spaceId=space_id,
        atmWorkflowExecutionId=workflow_execution_id,
        oneproviderId=oneprovider_id,
        oneproviderDomain=oneprovider_domain,
        onezoneDomain=onezone_domain,
        accessToken=access_token,
        heartbeatUrl="",
        timeoutSeconds=timeout_seconds,
        logLevel=log_level,
        config=config,
    )

    context: JobContext[Any] = JobContext(
        config=config,
        user_id=user_id,
        space_id=space_id,
        workflow_execution_id=workflow_execution_id,
        oneprovider_id=oneprovider_id,
        oneprovider_domain=oneprovider_domain,
        onezone_domain=onezone_domain,
        access_token=access_token,
        timeout_seconds=timeout_seconds,
        log_level=log_level,
        heartbeat=heartbeat,
        result_streamer_factory=result_streamer_factory,
        logger_factory=logger_factory,
        raw=raw,
    )
    return RecordedContext(context, logs, streams, heartbeats)


# --- Integration testing: through the real run() -------------------------------------
# Drive the real runtime end-to-end in dev mode against an in-memory wire request and
# capture what reached the response envelope and the `/out/<stream>` files.


@dataclass
class LocalRunResult:
    """The outcome of `run_local`: the response envelope plus captured stream contents."""

    # The dict `run()` returned -- `{"resultsBatch": [...]}` or `{"exception": ...}`.
    envelope: dict[str, Any]
    # Items written to each `/out/<name>` stream during the run (parsed JSON lines), by name.
    streams: dict[str, list[Any]]


def build_request(
    args_batch: list[Any],
    *,
    config: Any = None,
    log_level: LogLevel = "info",
    user_id: str = "test-user",
    space_id: str = "test-space",
    workflow_execution_id: str = "test-workflow-execution",
    oneprovider_id: str = "test-oneprovider",
    oneprovider_domain: str = "oneprovider.test",
    onezone_domain: str = "onezone.test",
    access_token: str = "test-token",
    heartbeat_url: str = "https://heartbeat.test",
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    """
    Build a raw wire request (the dict `run()` parses), with a per-job `__meta.traceId`.

    The integration-layer counterpart to `build_jobs`/`build_job_context`: pass the result to
    `run_local` (or `json.dumps` it and call `run` yourself). Each item of `args_batch` is one
    job's arguments; the `__meta` envelope the framework adds on the wire is injected here.
    """
    return {
        "ctx": {
            "userId": user_id,
            "spaceId": space_id,
            "atmWorkflowExecutionId": workflow_execution_id,
            "oneproviderId": oneprovider_id,
            "oneproviderDomain": oneprovider_domain,
            "onezoneDomain": onezone_domain,
            "accessToken": access_token,
            "heartbeatUrl": heartbeat_url,
            "timeoutSeconds": timeout_seconds,
            "logLevel": log_level,
            "config": config,
        },
        "argsBatch": [
            {**args, "__meta": {"traceId": f"test-{i}"}} for i, args in enumerate(args_batch)
        ],
    }


def run_local(
    handler: Callable[..., Any],
    request: dict[str, Any] | str,
    *,
    out_dir: str | os.PathLike[str],
) -> LocalRunResult:
    """
    Drive the real runtime `run(handler, raw)` in dev mode and capture its side effects.

    Runs in dev mode (`ONEDATA_LAMBDA_DEV=1`: heartbeats logged not POSTed, no stdout
    redirect, no Oneclient mount-wait) with the streaming output directory pointed at
    `out_dir` (pass a pytest `tmp_path`). Returns the response envelope plus the items each
    stream received, so an integration test can assert on both -- the seam unit tests skip:
    wire parsing, `JobContext` construction, the buffered flusher writing files, and
    envelope assembly.

    `request` is a wire request dict (see `build_request`) or a raw JSON string.
    """
    raw = request if isinstance(request, str) else json.dumps(request)
    with _dev_mode():
        envelope = run(handler, raw, out_dir=os.fspath(out_dir))
    return LocalRunResult(envelope=dict(envelope), streams=_read_streams(out_dir))


@contextlib.contextmanager
def _dev_mode() -> Iterator[None]:
    previous = os.environ.get(ENV_DEV_MODE)
    os.environ[ENV_DEV_MODE] = "1"
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop(ENV_DEV_MODE, None)
        else:
            os.environ[ENV_DEV_MODE] = previous


def _read_streams(out_dir: str | os.PathLike[str]) -> dict[str, list[Any]]:
    streams: dict[str, list[Any]] = {}
    for name in sorted(os.listdir(out_dir)):
        path = os.path.join(os.fspath(out_dir), name)
        if not os.path.isfile(path):
            continue
        with open(path) as stream_file:
            streams[name] = [json.loads(line) for line in stream_file if line.strip()]
    return streams
